ALTER TABLE empleados
	ADD COLUMN tipo ENUM ('director', 'representante');
    
UPDATE empleados
	SET tipo = 'director'
    WHERE nuemp IN (104, 106, 108);

UPDATE empleados
	SET tipo = 'representante'
    WHERE nuemp IN (101, 102, 103, 105, 107, 109, 110);
    
INSERT INTO directores 
	SELECT nuemp
			FROM empleados
            WHERE tipo = 'director';

INSERT INTO representantes
	SELECT nuemp, cuota, ventas
    FROM empleados
    WHERE tipo = 'representante';
    
ALTER TABLE empleados
	DROP COLUMN cuota,
    DROP COLUMN ventas;
    
ALTER TABLE clientes
	DROP CONSTRAINT clientes_empleados;
    
ALTER TABLE clientes
	ADD CONSTRAINT clientes_representantes
    FOREIGN KEY (gestor) 
		REFERENCES representantes(id_representante);

ALTER TABLE oficinas
	DROP CONSTRAINT fk_oficinas_empleados;

ALTER TABLE oficinas
	ADD CONSTRAINT oficinas_directores
	FOREIGN KEY (director)
		REFERENCES directores(id_director);

